package br.com.cursoapi.principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCursoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCursoApplication.class, args);
	}

}
