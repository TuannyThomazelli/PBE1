package br.com.cursoapi.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursoapi.principal.Entities.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno,Long> {
	

}



	

