package br.com.cursoapi.principal.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Curso {
	
	//atributos
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_Curso;

	@Column(name = "Nome_Curso")
	private String Nome_Curso;
	@Column(name = "Descricao")
	private String Descricao;
	@Column(name = "Carga_horaria")
	private int Carga_horaria;
	@Column(name = "Nivel_dificuldade")
	private int Nivel_dificuldade;
	
	//Construtores
	
	public Curso (){
		
	}
	public Curso(long id_Curso, String Nome_Curso, String Descricao, int Carga_horaria, int Nivel_dificuldade) {
	this.id_Curso = id_Curso;
	this.Nome_Curso = Nome_Curso;
	this.Descricao = Descricao;
	this.Carga_horaria = Carga_horaria;
	this.Nivel_dificuldade = Nivel_dificuldade;
		
	}
	
	//Getters e Setters
	public long getId_Curso() {
		return id_Curso;
	}
	public void setId_Curso(long id_Curso) {
		this.id_Curso = id_Curso;
	}
	public String getNome_Curso() {
		return Nome_Curso;
	}
	public void setNome_Curso(String nome_Curso) {
		Nome_Curso = nome_Curso;
	}
	public String getDescricao() {
		return Descricao;
	}
	public void setDescricao(String descricao) {
		Descricao = descricao;
	}
	public int getCarga_horaria() {
		return Carga_horaria;
	}
	public void setCarga_horaria(int carga_horaria) {
		Carga_horaria = carga_horaria;
	}
	public int getNivel_dificuldade() {
		return Nivel_dificuldade;
	}
	public void setNivel_dificuldade(int nivel_dificuldade) {
		Nivel_dificuldade = nivel_dificuldade;
	}
	

	

}
