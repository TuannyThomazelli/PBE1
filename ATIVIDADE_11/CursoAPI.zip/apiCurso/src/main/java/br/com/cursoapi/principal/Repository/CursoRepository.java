package br.com.cursoapi.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import br.com.cursoapi.principal.Entities.Curso;

public interface CursoRepository extends JpaRepository<Curso,Long> {
	

}

