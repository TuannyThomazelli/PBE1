package br.com.cursoapi.principal.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Disciplina {

	//atributos
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_Disciplina;

	@Column(name = "Nome")
	private String Nome;
	@Column(name = "Carga_horaria")
	private int Carga_horaria;
	@Column(name = "Horario")
	private int Horario;
	@Column(name = "Descricao")
	private String Descricao;
	
	//Construtores
	public Disciplina() {
		
	}
	public Disciplina(long id_Disciplina, String Nome, int Carga_horaria, int Horario, String Descricao) {
		this.id_Disciplina = id_Disciplina;
		this.Nome = Nome;
		this.Carga_horaria = Carga_horaria;
		this.Horario = Horario;
		this.Descricao = Descricao;
		
		//Getters e Setters
	}
	public long getId_Disciplina() {
		return id_Disciplina;
	}
	public void setId_Disciplina(long id_Disciplina) {
		this.id_Disciplina = id_Disciplina;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public int getCarga_horaria() {
		return Carga_horaria;
	}
	public void setCarga_horaria(int carga_horaria) {
		Carga_horaria = carga_horaria;
	}
	public int getHorario() {
		return Horario;
	}
	public void setHorario(int horario) {
		Horario = horario;
	}
	public String getDescricao() {
		return Descricao;
	}
	public void setDescricao(String descricao) {
		Descricao = descricao;
	}

}
