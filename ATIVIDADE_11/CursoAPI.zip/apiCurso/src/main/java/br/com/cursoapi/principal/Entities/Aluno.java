package br.com.cursoapi.principal.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Aluno {
	
	//Atributos
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_Aluno;

	@Column(name = "Nome")
	private String Nome;
	@Column(name = "Email")
	private String Email;
	@Column(name = "Telefone")
	
	private int Telefone;
	@Column(name = "Matricula")
	private String Matricula;
	
	//Construtores
	public Aluno() {
		
	}
	public Aluno(long id_Aluno, String Nome, String Email, int Telefone, String Matricula) {
		this.id_Aluno = id_Aluno;
		this.Nome = Nome;
		this.Email = Email;
		this.Telefone = Telefone;
		this.Matricula = Matricula;
	}
	
	//Getters e Setters
	public long getId_Aluno() {
		return id_Aluno;
	}
	public void setId_Aluno(long id_Aluno) {
		this.id_Aluno = id_Aluno;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getTelefone() {
		return Telefone;
	}
	public void setTelefone(int telefone) {
		Telefone = telefone;
	}
	public String getMatricula() {
		return Matricula;
	}
	public void setMatricula(String matricula) {
		Matricula = matricula;
	}


	
}
