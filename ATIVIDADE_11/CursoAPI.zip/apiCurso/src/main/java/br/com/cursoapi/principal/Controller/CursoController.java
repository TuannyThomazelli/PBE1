package br.com.cursoapi.principal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursoapi.principal.Entities.Curso;
import br.com.cursoapi.principal.Service.CursoService;


@RestController
@RequestMapping("/CursoController")
public class CursoController {
	@Autowired
	private CursoService CursoService;

	@PostMapping
	public Curso createCurso(@RequestBody Curso curso) {
		return CursoService.saveCurso(curso);
	}

	@GetMapping
	public List<Curso> getAllCurso() {
		return CursoService.getAllCurso();
	}

	@GetMapping("/{id}")
	public Curso getCurso(@PathVariable Long id) {
		return CursoService.getCursoById(id);
	}

	@DeleteMapping("/{id}")
	public void deleteCurso(@PathVariable Long id) {
		CursoService.deleteCurso(id);
	}
}



	

