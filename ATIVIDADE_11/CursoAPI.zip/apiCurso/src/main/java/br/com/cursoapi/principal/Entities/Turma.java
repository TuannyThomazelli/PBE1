package br.com.cursoapi.principal.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Turma {
	
	//atributos
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_Turma;

	@Column(name = "Data_inicio")
	private int Data_inicio;
	@Column(name = "Data_Termino")
	private int Data_Termino;
	@Column(name = "Horario")
	private int Horario;
	@Column(name = "Numero_vagas")
	private int Numero_vagas;

	
	//Construtores
	
	public Turma() {
		
	}
	
	public Turma(long id_Turma, int Data_inicio,int Data_Termino, int Horario, int Numero_vagas) {
		this.id_Turma = id_Turma;
		this.Data_inicio = Data_inicio;
		this.Data_Termino = Data_Termino;
		this.Horario = Horario;
		this.Numero_vagas = Numero_vagas;
	}

	//Getters e Setters
	public long getId_Turma() {
		return id_Turma;
	}

	public void setId_Turma(long id_Turma) {
		this.id_Turma = id_Turma;
	}

	public int getData_inicio() {
		return Data_inicio;
	}

	public void setData_inicio(int data_inicio) {
		Data_inicio = data_inicio;
	}

	public int getData_termino() {
		return Data_Termino;
	}

	public void setData_termino(int data_termino) {
		Data_Termino = data_termino;
	}

	public int getHorario() {
		return Horario;
	}

	public void setHorario(int horario) {
		Horario = horario;
	}

	public int getNumero_vagas() {
		return Numero_vagas;
	}

	public void setNumero_vagas(int numero_vagas) {
		Numero_vagas = numero_vagas;
	}
	
	
}
