package br.com.cursoapi.principal.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursoapi.principal.Entities.Disciplina;
import br.com.cursoapi.principal.Repository.DisciplinaRepository;



@Service
public class DisciplinaService {

@Autowired
	
	private DisciplinaRepository disciplinaRepository;
	
	public Disciplina saveDisciplina(Disciplina disciplina) {
		return disciplinaRepository.save(disciplina);
	}

	public List<Disciplina> getAllDisciplina() {
		return disciplinaRepository.findAll();
	}

	public Disciplina getDisciplinaById(Long id) {
		return disciplinaRepository.findById(id).orElse(null);
	}

	public void deleteDisciplina(Long id) {
		disciplinaRepository.deleteById(id);
		
	}
}
