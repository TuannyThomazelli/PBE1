package br.com.cursoapi.principal.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cursoapi.principal.Entities.Aluno;
import br.com.cursoapi.principal.Repository.AlunoRepository;

@Service
public class AlunoService {
	@Autowired

	private AlunoRepository alunoRepository;

	public Aluno saveAluno(Aluno aluno) {
		return alunoRepository.save(aluno);
	}

	public List<Aluno> getAllAluno() {
		return alunoRepository.findAll();
	}

	public Aluno getAlunoById(Long id) {
		return alunoRepository.findById(id).orElse(null);
	}

	public void deleteAluno(Long id) {
		alunoRepository.deleteById(id);

	}
}
