package br.com.cursoapi.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import br.com.cursoapi.principal.Entities.Turma;

public interface TurmaRepository extends JpaRepository<Turma,Long> {
	

}
