package br.com.cursoapi.principal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursoapi.principal.Entities.Aluno;
import br.com.cursoapi.principal.Service.AlunoService;

@RestController
@RequestMapping("/AlunoController")
public class AlunoController {

	@Autowired
	private AlunoService AlunoService;

	@PostMapping
	public Aluno createAluno(@RequestBody Aluno aluno) {
		return AlunoService.saveAluno(aluno);
	}

	@GetMapping
	public List<Aluno> getAllAluno() {
		return AlunoService.getAllAluno();
	}

	@GetMapping("/{id}")
	public Aluno getAluno(@PathVariable Long id) {
		return AlunoService.getAlunoById(id);
	}

	@DeleteMapping("/{id}")
	public void deleteAluno(@PathVariable Long id) {
		AlunoService.deleteAluno(id);
	}
}
