package br.com.cursoapi.principal.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Instrutor {

	//atributos
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_Instrutor;

	@Column(name = "Nome")
	private String Nome;
	@Column(name = "Email")
	private String Email;
	@Column(name = "Telefone")
	private int Telefone;
	@Column(name = "Especializacao")
	private String Especializacao;
	@Column(name = "Experiencia")
	private String Experiencia;


	//Construtores
	public Instrutor() {
		
	}
	public Instrutor(long id_Instrutor,String Nome, String Email, int Telefone, String Especializacao, String Experiencia) {
		this.Nome = Nome;
		this.Email = Email;
		this.Telefone = Telefone;
		this.Especializacao = Especializacao;
		this.Experiencia = Experiencia;
	}
	
	//Getters e Setters 
	public long getId_Instrutor() {
		return id_Instrutor;
	}
	public void setId_Instrutor(long id_Instrutor) {
		this.id_Instrutor = id_Instrutor;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getTelefone() {
		return Telefone;
	}
	public void setTelefone(int telefone) {
		Telefone = telefone;
	}
	public String getEspecializacao() {
		return Especializacao;
	}
	public void setEspecializacao(String especializacao) {
		Especializacao = especializacao;
	}
	public String getExperiencia() {
		return Experiencia;
	}
	public void setExperiencia(String experiencia) {
		Experiencia = experiencia;
	}
	
	
}
