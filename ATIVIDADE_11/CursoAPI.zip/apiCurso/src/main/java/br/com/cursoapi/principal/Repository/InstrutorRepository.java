package br.com.cursoapi.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.cursoapi.principal.Entities.Instrutor;

public interface InstrutorRepository extends JpaRepository<Instrutor,Long> {
	

}

