package br.com.cursoapi.principal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.cursoapi.principal.Entities.Turma;
import br.com.cursoapi.principal.Service.TurmaService;



@RestController
@RequestMapping("/TurmaController")
public class TurmaController {

	@Autowired
	private TurmaService TurmaService;

	@PostMapping
	public Turma createTurma(@RequestBody Turma turma) {
		return TurmaService.saveTurma(turma);
	}

	@GetMapping
	public List<Turma> getAllTurma() {
		return TurmaService.getAllTurma();
	}

	@GetMapping("/{id}")
	public Turma getTurma(@PathVariable Long id) {
		return TurmaService.getTurmaById(id);
	}

	@DeleteMapping("/{id}")
	public void deleteTurma(@PathVariable Long id) {
		TurmaService.deleteTurma(id);
	}
}

