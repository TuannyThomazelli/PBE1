package br.com.cursoapi.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import br.com.cursoapi.principal.Entities.Disciplina;

public interface DisciplinaRepository extends JpaRepository<Disciplina,Long> {
	

}

