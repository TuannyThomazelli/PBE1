package br.com.cursoapi.principal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCursoApplicationTests {

	@Test
	void contextLoads() {
	}

}
