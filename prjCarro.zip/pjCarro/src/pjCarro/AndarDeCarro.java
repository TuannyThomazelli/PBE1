package pjCarro;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {
	
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Qual é a marca do carro: ");
		String marca = sc.nextLine();
		System.out.println("Qual é o modelo do carro: ");
		String modelo = sc.nextLine();
		System.out.println("Qual é a velocidade: ");
		int velocidade = sc.nextInt();
		
		
		System.out.println("Opções: ");
		System.out.println("1 Acelerar ");
		System.out.println("2 Freiar");
		System.out.println("Escolha a opção");
		int escolha = sc.nextInt();
		
		
		if(escolha == 1) {
			 System.out.println("Quanto você deseja acelerar");
			 int valor = sc.nextInt();
			 velocidade += valor;
		 }
		 else if(escolha == 2) {
			 System.out.println("Quanto vc quer desacelerar");
			 int valor = sc.nextInt();
			  velocidade -= valor;
		 }
		
		

		
	}

}
