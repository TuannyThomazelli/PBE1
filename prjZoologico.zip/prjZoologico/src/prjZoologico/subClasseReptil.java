package prjZoologico;

public class subClasseReptil extends ClassesAnimal{
	
	//Metodos
    public void metodoTrocarPele() {
	System.out.println(this.atributoNome + " Está trocando de pele"); 
}

    public void metodoRastejar() {
    	System.out.println(this.atributoNome + " Rasteja");
    	
    }
    @Override
    public void metodoEmitirSom() {
    	System.out.println("SSSSSsssSSS");
    }
    
}
