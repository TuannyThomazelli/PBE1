package prjZoologico;

public class SubclasseCarnivora extends ClassesAnimal {
 
	//Metodos
	public void metodoCacar() {
		System.out.println(this.atributoNome + " Está caçando");
	}
	
	@Override
	public void metodoEmitirSom() {
		System.out.println("Ahhrrrr");
	}
	
	
}