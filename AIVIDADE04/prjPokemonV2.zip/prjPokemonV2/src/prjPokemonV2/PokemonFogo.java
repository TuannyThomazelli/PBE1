package prjPokemonV2;

public class PokemonFogo extends Pokemon {

	@Override
	public void Atacar() {
		System.out.println(this.Nome +"Atirou uma bola de fogo");
	}
	@Override
	public void Atacar() {
		System.out.println(this.Nome + "Ele Explodiu" );
	} 
	@Override
	public void Atacar() {
		System.out.println(this.Nome + "Ele lançou chamas");
	}
	public void Evoluir () {
		System.out.println(this.Nome + "Ele evoluiu");
	}
}
