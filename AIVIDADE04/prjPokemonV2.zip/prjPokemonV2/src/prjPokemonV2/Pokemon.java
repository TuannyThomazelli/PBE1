package prjPokemonV2;

public class Pokemon {

	//Atributo//
	 String Nome;
     String Elemento;
	 int Evolucao;
	 int Hp;
	 int Defesa;
	
	//Construtores//
	public Pokemon () {
		
	}
	public Pokemon (String Nome, String Elemento, int Evolucao, int Hp, int Defesa) {
		this.Nome = Nome;
		this.Elemento = Elemento;
		this.Evolucao = Evolucao;
		this.Hp = Hp;
		this.Defesa = Defesa;
	
	
	
	//Getters and Setters
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getElemento() {
		return Elemento;
	}
	public void setElemento(String elemento) {
		Elemento = elemento;
	}
	public int getEvolucao() {
		return Evolucao;
	}
	public void setEvolucao(int evolucao) {
		Evolucao = evolucao;
	}
	public int getHp() {
		return Hp;
	}
	public void setHp(int hp) {
		Hp = hp;
	}
	public int getDefesa() {
		return Defesa;
	}
	public void setDefesa(int defesa) {
		Defesa = defesa;
	}
	
	//Metodos//	
		}
		public void Atacar() {
			System.out.println(this.Nome + "Ele atacou");
		}
		public void Evoluir() {
			System.out.println(this.Nome + "Ele evoluiu");
		}
	
	
	
	public void Info() {
		 System.out.println("Nome: " + this.Nome);
		 System.out.println("Elemento: " + this.Elemento);
		 System.out.println("Evolucao: " + this.Evolucao);
		 System.out.println("Hp: " + this.Hp);
		 System.out.println("Defesa: " + this.Defesa);
		 

	 }

}
