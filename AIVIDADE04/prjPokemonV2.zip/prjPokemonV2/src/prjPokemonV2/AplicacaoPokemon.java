package prjPokemonV2;

public class AplicacaoPokemon{


	public static void main(String[] args) {
		
		
		Pokemon Charizard = new Pokemon("Charizard", "Fogo", 3, 78, 78);
		
		Pokemon Piulup = new Pokemon("Piulup", "Agua", 1, 36, 53 );
	
		Pokemon Squirtle = new Pokemon("Squirtle ","Agua", 1, 44, 48 );
		 
		Pokemon Pidgey = new Pokemon("Pidgey", "Voador", 1, 40,40);
		
		Pokemon flareon = new Pokemon("Flareon", "Fogo", 2, 60, 65);
		
		Pokemon ninjask = new Pokemon("Ninjask", "Voador", 2,45,61);
		
		Charizard.Info();
		Charizard.Evoluir();
		Charizard.Atacar();
		
		Piulup.Info();
		Piulup.Evoluir();
		Piulup.Atacar();
		
		Squirtle.Info();
		Squirtle.Evoluir();
		Squirtle.Atacar();
		
		Pidgey.Info();
		Pidgey.Evoluir();
		Pidgey.Atacar();
		
		flareon.Info();
		flareon.Evoluir();
		flareon.Atacar();
		
		ninjask.Info();
		ninjask.Evoluir();
		ninjask.Atacar();
		
		
		
		
		
	}
	

}
