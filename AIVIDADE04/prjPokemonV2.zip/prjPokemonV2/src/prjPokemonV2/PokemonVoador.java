package prjPokemonV2;

public class PokemonVoador  extends Pokemon{

	public void Voar () {
		System.out.println(this.Nome + "Está Voando");
	}
	@Override
	public void Ataque() {
		System.out.println(this.Nome + "Fez um ataque de Asa");
	}
	public void Evoluir () {
		System.out.println(this.Nome + "Ele evoluiu");
	}

}

