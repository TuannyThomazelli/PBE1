package prjPokemonV2;

public class PokemonAgua extends Pokemon {

	public void Surfar () {
		System.out.println(this.Nome + "Está surfando");
	}
	@Override
	public void Ataque() {
		System.out.println(this.Nome + "Fez um ataque de agua");
	}
	public void Evoluir () {
		System.out.println(this.Nome + "Ele evoluiu");
	}

}



