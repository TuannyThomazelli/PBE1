package br.com.bibiotecasenai.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibiotecasenai.principal.Entities.Livro;

	public interface LivroRepository extends JpaRepository<Livro,Long> {
		

	}

