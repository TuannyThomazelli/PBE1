package br.com.bibiotecasenai.principal.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.bibiotecasenai.principal.Entities.Editora;
import br.com.bibiotecasenai.principal.Repository.EditoraRepository;

public class EditoraService {

	@Autowired
	
	private EditoraRepository editoraRepository;
	
	public Editora saveEditora(Editora editora) {
		return editoraRepository.save(editora);
	}

	public List<Editora> getAllEditora() {
		return editoraRepository.findAll();
	}

	public Editora getEditoraById(Long id) {
		return editoraRepository.findById(id).orElse(null);
	}

	public void deleteEditora(Long id) {
		editoraRepository.deleteById(id);
		
	}

	

}
