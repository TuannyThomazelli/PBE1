package br.com.bibiotecasenai.principal.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_Editora")
public class Editora {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id_Editora;
	
	@Column(name = "nome_editora")
	private String nome_editora;
	@Column (name = "cnpj")
	private String cnpj;
	@Column (name = "email")
	private String email;
	@Column (name = "contato")
	private String contato;
	
	//construtores
	public Editora () {
		
	}
	public Editora (long id_Editora, String nome_editora, String cnpj, String email, String contato) {
		this.id_Editora = id_Editora;
		this.nome_editora = nome_editora;
		this.cnpj = cnpj;
		this.email = email;
		this.contato = contato;
	}
	//getters e setters
	public long getId_Editora() {
		return id_Editora;
	}
	public void setId_Editora(long id_Editora) {
		this.id_Editora = id_Editora;
	}
	public String getNome_editora() {
		return nome_editora;
	}
	public void setNome_editora(String nome_editora) {
		this.nome_editora = nome_editora;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	
	
}
