package br.com.bibiotecasenai.principal.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.bibiotecasenai.principal.Entities.Livro;
import br.com.bibiotecasenai.principal.Repository.LivroRepository;

public class LivroService {

	@Autowired
	
	private LivroRepository livroRepository;
	
	public Livro saveLivro(Livro livro) {
		return livroRepository.save(livro);
	}

	public List<Livro> getAllLivro() {
		return livroRepository.findAll();
	}

	public Livro getLivroById(Long id) {
		return livroRepository.findById(id).orElse(null);
	}

	public void deleteLivro(Long id) {
		livroRepository.deleteById(id);
		
	}


	
		
	

}
