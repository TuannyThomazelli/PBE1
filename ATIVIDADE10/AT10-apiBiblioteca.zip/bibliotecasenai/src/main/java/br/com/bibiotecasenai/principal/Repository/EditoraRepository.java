package br.com.bibiotecasenai.principal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibiotecasenai.principal.Entities.Editora;

	
public interface EditoraRepository extends JpaRepository<Editora,Long> {
		

	}


